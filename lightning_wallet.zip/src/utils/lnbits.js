export async function createWallet() {
  const res = await fetch('https://legend.lnbits.com/wallet', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ wallet_name: 'WebWallet', user_name: 'webuser' })
  });
  const data = await res.json();
  return data;
}

export async function fetchBalance(wallet) {
  const res = await fetch('https://legend.lnbits.com/api/v1/wallet', {
    headers: { 'X-Api-Key': wallet.adminkey }
  });
  const data = await res.json();
  return data.balance;
}

export async function payInvoice(wallet, invoice) {
  const res = await fetch('https://legend.lnbits.com/api/v1/payments', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Api-Key': wallet.adminkey
    },
    body: JSON.stringify({ out: true, bolt11: invoice })
  });
  const data = await res.json();
  return data;
}
