import React, { useEffect, useState } from 'react';
import Wallet from '../components/Wallet';

export default function App() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <h1 className="text-3xl font-bold mb-4">Lightning Wallet ⚡</h1>
      <Wallet />
    </div>
  );
}
