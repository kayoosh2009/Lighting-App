import React, { useState } from 'react';
import QRCode from 'qrcode.react';
import { createWallet, payInvoice, fetchBalance } from '../utils/lnbits';

export default function Wallet() {
  const [wallet, setWallet] = useState(null);
  const [balance, setBalance] = useState(null);
  const [invoice, setInvoice] = useState('');
  const [amount, setAmount] = useState('');

  const handleCreate = async () => {
    const w = await createWallet();
    setWallet(w);
    const bal = await fetchBalance(w);
    setBalance(bal);
  };

  const handlePay = async () => {
    if (!wallet || !invoice) return;
    await payInvoice(wallet, invoice);
    alert('Invoice paid!');
  };

  return (
    <div className="w-full max-w-md">
      {!wallet ? (
        <button className="bg-blue-500 p-2 rounded" onClick={handleCreate}>Создать LNbits Кошелек</button>
      ) : (
        <div className="space-y-4">
          <div>Admin Key: {wallet.adminkey}</div>
          <div>Balance: {balance} sats</div>
          <input
            className="w-full p-2 bg-gray-800 rounded"
            value={invoice}
            onChange={(e) => setInvoice(e.target.value)}
            placeholder="Вставьте invoice"
          />
          <button className="bg-green-600 p-2 rounded" onClick={handlePay}>Оплатить</button>
          <QRCode value={wallet.lnurlpay || ''} />
        </div>
      )}
    </div>
  );
}
